import React, { useState, useContext } from "react";
import { SettingsContext } from "../context/SettingsContext";

export default function FuelLogForm({ vehicle, addFuelLog }) {
  const { distanceUnit } = useContext(SettingsContext);
  const [odo, setOdo] = useState("");
  const [fuel, setFuel] = useState("");

  const handleSubmit = (e) => {
    e.preventDefault();
    const lastOdo = vehicle.fuelLogs.length ? vehicle.fuelLogs[vehicle.fuelLogs.length - 1].odo : vehicle.odo;
    const distance = parseFloat(odo) - lastOdo;
    const mileage = distance / parseFloat(fuel);
    addFuelLog({ odo: parseFloat(odo), fuel: parseFloat(fuel), distance, mileage });
    setOdo("");
    setFuel("");
  };

  return (
    <form onSubmit={handleSubmit} className="p-4 bg-gray-100 rounded mb-4">
      <h2 className="text-lg font-bold mb-2">Add Fuel Log ({distanceUnit})</h2>
      <div className="flex gap-2">
        <input 
          placeholder={`ODO (${distanceUnit})`} 
          type="number" 
          value={odo} 
          onChange={(e) => setOdo(e.target.value)} 
          className="border px-2 py-1 rounded w-32"
        />
        <input 
          placeholder="Fuel (L)" 
          type="number" 
          value={fuel} 
          onChange={(e) => setFuel(e.target.value)} 
          className="border px-2 py-1 rounded w-32"
        />
        <button type="submit" className="bg-green-500 text-white px-4 rounded">Add</button>
      </div>
    </form>
  );
}
