import React from "react";

export default function VehicleList({ vehicles, selectVehicle, deleteVehicle }) {
  return (
    <div className="mb-4">
      <h2 className="text-lg font-bold mb-2">Vehicles</h2>
      <ul>
        {vehicles.map((v, idx) => (
          <li key={idx} className="flex justify-between items-center border p-2 mb-1 rounded">
            <span onClick={() => selectVehicle(v)} className="cursor-pointer">
              {v.number} | ODO: {v.odo}
            </span>
            <button 
              onClick={() => deleteVehicle(idx)} 
              className="text-red-500 font-bold"
            >
              Delete
            </button>
          </li>
        ))}
      </ul>
    </div>
  );
}
