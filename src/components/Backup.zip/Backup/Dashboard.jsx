import React from "react";

export default function Dashboard({ vehicle }) {
  const fuelLogs = vehicle.logs.filter(l=>l.type==="fuel").sort((a,b)=>a.odo-b.odo);
  let totalDistance = 0, totalFuel=0;

  for(let i=1;i<fuelLogs.length;i++){
    totalDistance += fuelLogs[i].odo - fuelLogs[i-1].odo;
    totalFuel += fuelLogs[i].amount;
  }

  const mileage = totalFuel ? (totalDistance/totalFuel).toFixed(2) : 0;
  const totalMaintenance = vehicle.logs.filter(l=>l.type==="maintenance").reduce((a,b)=>a+b.cost,0);
  const totalExpense = vehicle.logs.filter(l=>l.type==="expense").reduce((a,b)=>a+b.amount,0);

  return (
    <div className="bg-white p-4 rounded shadow mt-4">
      <h3 className="font-semibold mb-2">Summary</h3>
      <p>Total Distance: {totalDistance} km</p>
      <p>Total Fuel: {totalFuel} L</p>
      <p>Mileage: {mileage} km/L</p>
      <p>Total Maintenance Cost: ${totalMaintenance}</p>
      <p>Total Other Expenses: ${totalExpense}</p>
    </div>
  );
}
