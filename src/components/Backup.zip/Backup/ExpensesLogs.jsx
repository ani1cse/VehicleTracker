import React, { useState } from "react";

export default function ExpensesLogs({ vehicle, updateVehicle }) {
  const [desc, setDesc] = useState("");
  const [amount, setAmount] = useState("");
  const [date, setDate] = useState("");

  const handleAdd = e => {
    e.preventDefault();
    if(!desc || !amount || !date) return;
    const newLog = { id: Date.now(), type:"expense", desc, amount: parseFloat(amount), date };
    updateVehicle({ ...vehicle, logs:[...vehicle.logs, newLog] });
    setDesc(""); setAmount(""); setDate("");
  };

  const logs = vehicle.logs.filter(l=>l.type==="expense");

  return (
    <div className="mb-4 bg-white p-4 rounded shadow">
      <h3 className="font-semibold mb-2">Expense Logs</h3>
      <form onSubmit={handleAdd} className="flex gap-2 flex-wrap mb-2">
        <input placeholder="Description" value={desc} onChange={e=>setDesc(e.target.value)} className="border p-2"/>
        <input type="number" placeholder="Amount" value={amount} onChange={e=>setAmount(e.target.value)} className="border p-2"/>
        <input type="date" value={date} onChange={e=>setDate(e.target.value)} className="border p-2"/>
        <button className="bg-red-500 text-white px-4 py-2">Add</button>
      </form>
      <ul>
        {logs.map(l=><li key={l.id}>{l.date} - {l.desc} - ${l.amount}</li>)}
      </ul>
    </div>
  );
}
