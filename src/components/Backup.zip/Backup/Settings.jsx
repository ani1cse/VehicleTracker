import React, { useContext } from "react";
import { SettingsContext } from "../context/SettingsContext";

export default function Settings() {
  const { currency, setCurrency, distanceUnit, setDistanceUnit } = useContext(SettingsContext);

  return (
    <div className="p-4 bg-gray-100 rounded mb-4">
      <h2 className="text-lg font-bold mb-2">Settings</h2>
      <div className="flex gap-4">
        <div>
          <label className="block">Currency</label>
          <input 
            value={currency} 
            onChange={(e) => setCurrency(e.target.value)} 
            className="border px-2 py-1 rounded"
          />
        </div>
        <div>
          <label className="block">Distance Unit</label>
          <select 
            value={distanceUnit} 
            onChange={(e) => setDistanceUnit(e.target.value)}
            className="border px-2 py-1 rounded"
          >
            <option value="km">Kilometers (km)</option>
            <option value="miles">Miles</option>
          </select>
        </div>
      </div>
    </div>
  );
}
