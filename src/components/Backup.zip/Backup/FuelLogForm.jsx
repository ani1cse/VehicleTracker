import React, { useState } from "react";

export default function FuelLogForm({ addFuelLog }) {
  const [fuel, setFuel] = useState("");
  const [price, setPrice] = useState("");

  const handleSubmit = (e) => {
    e.preventDefault();
    if (!fuel || !price) return;
    addFuelLog({ fuel: parseFloat(fuel), price: parseFloat(price), date: new Date() });
    setFuel("");
    setPrice("");
  };

  return (
    <form onSubmit={handleSubmit} className="flex gap-2 mb-4">
      <input
        type="number"
        placeholder="Liters"
        value={fuel}
        onChange={(e) => setFuel(e.target.value)}
        className="border p-1 rounded"
      />
      <input
        type="number"
        placeholder="Price"
        value={price}
        onChange={(e) => setPrice(e.target.value)}
        className="border p-1 rounded"
      />
      <button type="submit" className="bg-blue-500 text-white px-3 rounded">
        Add Fuel
      </button>
    </form>
  );
}
