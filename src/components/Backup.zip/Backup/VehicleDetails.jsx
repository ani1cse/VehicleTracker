import React, { useContext } from "react";
import FuelLogForm from "./FuelLogForm";
import { SettingsContext } from "../context/SettingsContext";
import { BarChart, Bar, XAxis, YAxis, Tooltip, ResponsiveContainer } from "recharts";

export default function VehicleDetails({ vehicle, updateVehicle }) {
  const { currency, distanceUnit } = useContext(SettingsContext);

  const addFuelLog = (log) => {
    const updated = { ...vehicle, fuelLogs: [...vehicle.fuelLogs, log] };
    updateVehicle(updated);
  };

  const totalFuel = vehicle.fuelLogs.reduce((acc, f) => acc + f.fuel, 0);
  const totalDistance = vehicle.fuelLogs.reduce((acc, f) => acc + f.distance, 0);
  const avgMileage = totalDistance / totalFuel || 0;

  return (
    <div className="p-4 bg-gray-50 rounded">
      <h2 className="text-lg font-bold mb-2">{vehicle.number} Details</h2>
      <FuelLogForm vehicle={vehicle} addFuelLog={addFuelLog} />

      <div className="mb-4">
        <h3 className="font-bold">Summary</h3>
        <p>Total Distance: {totalDistance.toFixed(2)} {distanceUnit}</p>
        <p>Total Fuel: {totalFuel.toFixed(2)} L</p>
        <p>Average Mileage: {avgMileage.toFixed(2)} {distanceUnit}/L</p>
      </div>

      <div style={{ width: "100%", height: 300 }}>
        <ResponsiveContainer>
          <BarChart data={vehicle.fuelLogs}>
            <XAxis dataKey="odo" />
            <YAxis />
            <Tooltip />
            <Bar dataKey="mileage" fill="#8884d8" />
          </BarChart>
        </ResponsiveContainer>
      </div>
    </div>
  );
}
